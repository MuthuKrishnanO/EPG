package ridsys.example.com.linear_layout;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.util.JsonReader;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.ScrollView;
import android.support.v4.app.NavUtils;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class MainActivity extends Activity {
    private static int SCREEN_HEIGHT;
    private static int SCREEN_WIDTH;
Button button;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getScreenDimension();

        button=(Button)findViewById(R.id.live);


     /*  final HorizontalScrollView hsv=(HorizontalScrollView)findViewById(R.id.l) ;
        hsv.post(new Runnable() {
            @Override
            public void run() {
                // Get the button.
                View button = findViewById(R.id.l);

                // Locate the button.
                int x, y;
                x = button.getLeft();
                y = button.getTop();
                Log.i("gg",String.valueOf(x));

                // Scroll to the button.
                hsv.scrollTo(x*100,10000);



            }
        });*/

        List<Date> date = new ArrayList<Date>();
        date.add(new Date());
        Log.i("date",String.valueOf(date));

        Calendar now = Calendar.getInstance();

        System.out.println("Current date : " + (now.get(Calendar.MONTH) + 1)
                + "-"
                + now.get(Calendar.DATE)
                + "-"
                + now.get(Calendar.YEAR));



        //add days to current date using Calendar.add method
        now.add(Calendar.DATE,1);
        String[] calender = new String[100];
        for(int i=0;i<7;i++) {
            System.out.println("date after one day : " + (now.get(Calendar.MONTH) + 1)
                    + "-"
                    + (now.get(Calendar.DATE)+i)
                    + "-"
                    + now.get(Calendar.YEAR));
             calender[i]= (now.get(Calendar.MONTH) + 1) + "-" + now.get(Calendar.DATE) + "-" + now.get(Calendar.YEAR);
            Log.i("calender",String.valueOf(calender[i]));
        }
        Log.i("now",String .valueOf(now));


        //substract days from current date using Calendar.add method





        List<String> urls = new ArrayList<>( );
        String[] chennal = {"521","190","615","556","191","504","155","142","523","554","570","640","473","542"};
        //"521","190","615","556","191","504","155","142","523","554","570","640","473","542"
        //"360","321","550","641","633","638"
        String[] date1={"2018-07-25"};
        for(int i=0;i<date1.length;i++) {
            for (int j = 0; j < chennal.length; j++) {
                urls.add("http://192.168.70.200:8080/REPG/getSchedule?channelId=" + chennal[j] + "&edate="+date1[i]);
            }
        }
         // urls.add("https://api.myjson.com/bins/14plcy");
        //urls.add("https://api.myjson.com/bins/iz9s2");

        MyAsyncTask myAsyncTask = new MyAsyncTask(MainActivity.this, urls);
        myAsyncTask.execute( );
       // linear();


    }
    public class MyAsyncTask extends AsyncTask<Void, Void, List<JSONArray>> {

        private Activity activity;
        private List<String> urls;

        public MyAsyncTask(Activity activity, List<String> urls) {
            this.urls = urls;
            this.activity = activity;
        }

        @Override
        protected List<JSONArray> doInBackground(Void... voids) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            StringBuilder sb = null;

            List<JSONArray> jsonURls = new ArrayList<>( );
            try {
                for (String url : urls) {
                    URL link = new URL(url);
                    connection = (HttpURLConnection) link.openConnection( );
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setRequestMethod("GET");
                    connection.connect( );

                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream( ), "UTF-8"));
                    String line = null;
                    sb = new StringBuilder( );

                    while ((line = reader.readLine( )) != null) {
                        sb.append(line);
                    }
                    // Log.i("sb",sb.toString());

                    reader.close( );
                    JSONArray jsonResult = new JSONArray(sb.toString( ));
                    jsonURls.add(jsonResult);


                }
            } catch (MalformedURLException e) {
                e.printStackTrace( );
                Toast.makeText(activity, "URL error", Toast.LENGTH_SHORT).show( );
            } catch (IOException e) {
                e.printStackTrace( );
                Toast.makeText(activity, "Connection error", Toast.LENGTH_SHORT).show( );
            } catch (JSONException e) {
                e.printStackTrace( );
                Toast.makeText(activity, "JSON Parsing error", Toast.LENGTH_SHORT).show( );
            }
            return jsonURls;

        }

        @Override
        protected void onPostExecute(List<JSONArray> jsonObjects) {
            super.onPostExecute(jsonObjects);
            setLinearA(jsonObjects);
            setLinearB();
            setLinearC(jsonObjects);

            JsonData(jsonObjects);


        }
    }
    private void getScreenDimension() {
        WindowManager wm = (WindowManager) getApplicationContext( ).getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay( );
        Point size = new Point( );
        display.getSize(size);
        SCREEN_WIDTH = 1800;
        SCREEN_HEIGHT = size.y;

    }
private void  setLinearA(List<JSONArray>jsonObject)
{

    LinearLayout linearLayout=(LinearLayout)findViewById(R.id.date);
    JSONArray ja = new JSONArray(jsonObject);

        JSONArray arr2 = ja.optJSONArray(0);

        TextView textView = new TextView(this);
        try {
            String data = arr2.getJSONObject(0).getString("e_date");
            textView.setText(data);
            textView.setTextColor(Color.parseColor("#ffffff"));


            Log.i("data", String.valueOf(data));
        } catch (JSONException e) {
            e.printStackTrace( );
        }
        linearLayout.addView(textView);






}
    private void JsonData(List<JSONArray> jsonObject) {
        JSONArray ja = new JSONArray(jsonObject);


        int buttonSerial = 0;
        LinearLayout linearLayoutA=(LinearLayout)findViewById(R.id.eventlist);

        for (int j = 0; j <ja.length( ); j++) {
            LinearLayout linearLayout = new LinearLayout(this);
           // LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, SCREEN_HEIGHT/20);
            linearLayout.setId(j);


            final JSONArray arr2 = ja.optJSONArray(j);
            try {
                String data=arr2.getJSONObject(0).getString("o_start_time");
                Log.i("data",String.valueOf(data));
            } catch (JSONException e) {
                e.printStackTrace( );
            }
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);

           // linearLayout.setLayoutParams(params);

            for(int i = 0; i <arr2.length()+1; i++) {

                Log.i("length",String.valueOf(arr2.length()));
                try {
                    JSONObject jo = arr2.getJSONObject(i);
                    String time11 = "2018-07-18 00:00:00";
                    String sub1 = time11.substring(11, 19);
                    Log.i("sub",sub1.toString());

                    String time2 = arr2.getJSONObject(0).getString("o_start_time");
                    String sub = time2.substring(11, 19);
                   // Log.i("sub", sub1.toString( ));
                    SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
                    Date date1 = null;

                    try {
                        date1 = format.parse(sub1);
                        Date date2 = format.parse(sub);
                        int difference = (int) ((date2.getTime( ) - date1.getTime( )) / 1000);
                       // Log.i("difference",String.valueOf(difference));
                        int d=arr2.getJSONObject(i).getInt("e_duration");


                        final TextView newButton = new TextView(this);
                        newButton.setId(i);
                        newButton.setText(arr2.getJSONObject(i).getString("e_title"));
                        newButton.setWidth((d / 5));
                        newButton.setHeight(1008 / 15);
                        newButton.setTextColor(Color.parseColor("#ffffff"));
                         newButton.setBackground(getResources( ).getDrawable(R.drawable.cell_background));
                        final int finalI = i;
                        newButton.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                try {
                                    Toast.makeText(MainActivity.this, arr2.getJSONObject(finalI).getString("e_description") + " clicked", Toast.LENGTH_LONG).show();
                                } catch (JSONException e) {
                                    e.printStackTrace( );
                                }


                            }
                        });






                        linearLayout.addView(newButton);

                    } catch (ParseException e) {
                        e.printStackTrace( );
                    }


                } catch (JSONException e) {
                    e.printStackTrace( );
                }
            }
            linearLayoutA.addView(linearLayout);
        }




    }
    private void setLinearB()
    {
        String[] time = {"00.00", "00.30", "1:00", "1:30", "2:00", "2:30", "3:00", "3:30", "4:00", "4:30",
                "5:00", "5:30", "6:00", "6:30", "7:00", "7:30", "8:00", "8:30", "9:00", "9:30", "10:00",
                "10:30", "11:00", "11:30", "12.00", "12.30", "13.00", "13.30", "14.00", "14.30", "15.00", "15.30", "16.00", "16.30",
                "17.00", "17.30", "18.00", "18.30", "19.00", "19.30", "20.00", "20.30", "21.00", "21.30", "22.00", "22.30",
                "23.00", "23.30"};
        final HorizontalScrollView hsv = (HorizontalScrollView) findViewById(R.id.l);
        List<String> time1 = Arrays.asList(time);
        LinearLayout linearLayoutA=(LinearLayout)findViewById(R.id.eventlist);

        LinearLayout linearLayoutB=new LinearLayout(this);
      //  linearLayoutB.setLayoutParams(new RelativeLayout.LayoutParams(SCREEN_WIDTH- (SCREEN_WIDTH/5), SCREEN_HEIGHT/20));
        linearLayoutB.setOrientation(LinearLayout.HORIZONTAL);


        for(int i=0;i<48;i++)
        {
            final TextView textB=new TextView(this);
            textB.setText(time[i]);
            //textB.setId(String.valueOf(time1));
            textB.setBackground(getResources( ).getDrawable(R.drawable.cell_background));
            textB.setId(i);
            textB.setWidth(1800/5);
            textB.setHeight(1008/20);
            textB.setTextColor(Color.parseColor("#0d130f"));
            linearLayoutB.addView(textB);
            textB.setBackgroundColor(Color.parseColor("#ffffff"));



        }
        linearLayoutA.addView(linearLayoutB);

        hsv.post(new Runnable( ) {

            @Override
            public void run() {
                long date = System.currentTimeMillis();

                // for current date
                SimpleDateFormat time1 = new SimpleDateFormat("kk:mm:ss");  // for 24 hour time

                //This will return current date in 31-12-2018 format
                String timeString1 = time1.format(date);  //This will return current time in 24 Hour format
                String time11 = "2018-07-18 00:00:00";
                String sub1 = time11.substring(11, 19);
                final int difference;

                Date date1 = null;
                try {
                    date1 = time1.parse(timeString1);
                    Date date2 = time1.parse(sub1);
                    difference = (int) ((date1.getTime( ) - date2.getTime( )) / 1000);
                    Log.i("difference",String.valueOf(difference));

                    button=(Button)findViewById(R.id.live);
                    button.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {


                            hsv.scrollTo(difference/5, 0);
                        }
                    });

                    hsv.scrollTo(difference/5, 0);

                } catch (ParseException e) {
                    e.printStackTrace( );
                }





                Log.e("TAG_1", "24 hour Time - " + timeString1);






            }
        });

    }
    public  void setLinearC(List<JSONArray> jsonObjects)
    {
        LinearLayout linearLayout1=(LinearLayout)findViewById(R.id.chennallist);
        JSONArray ja = new JSONArray(jsonObjects);
        for (int i = 0; i<ja.length(); ++i)
        {
            LinearLayout linearLayoutC=new LinearLayout(this);
           // linearLayoutC.setLayoutParams(new RelativeLayout.LayoutParams(SCREEN_WIDTH/5, SCREEN_HEIGHT - (SCREEN_HEIGHT/20)));
            linearLayoutC.setId(i);
           // linearLayoutC.setPadding(0, 0+(i*50), 0, 0);
            linearLayoutC.setOrientation(LinearLayout.VERTICAL);
            linearLayoutC.setBackgroundColor(Color.parseColor("#ffffff"));

            JSONArray arr2 = ja.optJSONArray(i);
            TextView textC=new TextView(this);
            try {
                textC.setText(arr2.getJSONObject(i).getString("serviceId"));
                textC.setBackground(getResources( ).getDrawable(R.drawable.cell_background));
                textC.setTextColor(Color.parseColor("#0d130f"));
                textC.setWidth(1800/5);
                textC.setHeight(1008/15);


            } catch (JSONException e) {
                e.printStackTrace( );
            }
            linearLayoutC.addView(textC);


            linearLayout1.addView(linearLayoutC);
        }



    }


}
/* private void JsonData(List<JSONArray> jsonObject) {
        JSONArray ja = new JSONArray(jsonObject);


        int buttonSerial = 0;
        LinearLayout linearLayoutA=(LinearLayout)findViewById(R.id.eventlist);

        for (int j = 0; j <ja.length( ); j++) {
            LinearLayout linearLayout = new LinearLayout(this);
           // LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, SCREEN_HEIGHT/20);
            linearLayout.setId(j);


            JSONArray arr2 = ja.optJSONArray(j);
            try {
                String data=arr2.getJSONObject(0).getString("o_start_time");
                Log.i("data",String.valueOf(data));
            } catch (JSONException e) {
                e.printStackTrace( );
            }
            linearLayout.setOrientation(LinearLayout.HORIZONTAL);

           // linearLayout.setLayoutParams(params);

            for(int i = 0; i <arr2.length()+1; i++) {

                Log.i("length",String.valueOf(arr2.length()));
                try {
                    JSONObject jo = arr2.getJSONObject(i);
                    String time11 = "2018-07-18 00:00:00";
                    String sub1 = time11.substring(11, 19);
                    Log.i("sub",sub1.toString());

                    String time2 = arr2.getJSONObject(0).getString("o_start_time");
                    String sub = time2.substring(11, 19);
                   // Log.i("sub", sub1.toString( ));
                    SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
                    Date date1 = null;

                    try {
                        date1 = format.parse(sub1);
                        Date date2 = format.parse(sub);
                        int difference = (int) ((date2.getTime( ) - date1.getTime( )) / 1000);
                       // Log.i("difference",String.valueOf(difference));
                        int d=arr2.getJSONObject(i).getInt("e_duration");

                        TextView newButton = new TextView(this);
                        newButton.setId(buttonSerial);
                        newButton.setText(arr2.getJSONObject(i).getString("e_title"));
                        newButton.setWidth(d / 5);
                        newButton.setHeight(1008 / 15);
                        newButton.setTextColor(Color.parseColor("#0d130f"));
                         newButton.setBackground(getResources( ).getDrawable(R.drawable.cell_background));



                        linearLayout.addView(newButton);

                    } catch (ParseException e) {
                        e.printStackTrace( );
                    }


                } catch (JSONException e) {
                    e.printStackTrace( );
                }
            }
            linearLayoutA.addView(linearLayout);
        }




    }*/


